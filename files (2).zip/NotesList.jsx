// =============================================================================
// FILE: src/components/NotesList.jsx
// PURPOSE: Displays the decrypted notes with integrity/signature status badges
// =============================================================================

export default function NotesList({ notes, loading, onDelete, onRefresh }) {
  if (loading) {
    return (
      <div className="notes-loading">
        <div className="spinner"></div>
        <p>Verifying signatures and decrypting notes...</p>
      </div>
    );
  }

  if (notes.length === 0) {
    return (
      <div className="notes-empty">
        <p>🔒 Your vault is empty. Add your first secret note above!</p>
      </div>
    );
  }

  return (
    <div className="notes-list">
      <div className="notes-actions">
        <button className="btn-refresh" onClick={onRefresh}>
          🔄 Refresh Vault
        </button>
      </div>

      {notes.map((note) => (
        <NoteCard key={note.id} note={note} onDelete={onDelete} />
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Individual Note Card
// ─────────────────────────────────────────────────────────────────────────────

function NoteCard({ note, onDelete }) {
  const [showDelete, setShowDelete] = useState(false);

  // Determine card styling based on integrity status
  const cardClass = {
    verified: "note-card note-verified",
    tampered: "note-card note-tampered",
    decrypt_failed: "note-card note-failed"
  }[note.integrity] || "note-card note-verified";

  return (
    <div className={cardClass}>
      <div className="note-header">
        {/* Integrity badge — shows result of RSA signature verification */}
        <span className={`integrity-badge badge-${note.integrity}`}>
          {note.integrity_label}
        </span>
        <span className="note-date">
          🕐 {new Date(note.created_at).toLocaleString()}
        </span>
      </div>

      {/* Note content — already AES-decrypted by the backend */}
      <div className="note-content">
        {note.integrity === "tampered"
          ? <em style={{ color: "#e74c3c" }}>⚠️ This note was flagged as tampered. Content hidden for security.</em>
          : note.content
        }
      </div>

      {/* Delete button (only for valid notes) */}
      {note.integrity !== "tampered" && (
        <div className="note-footer">
          {!showDelete ? (
            <button className="btn-delete-init" onClick={() => setShowDelete(true)}>
              🗑️ Delete
            </button>
          ) : (
            <div className="delete-confirm">
              <span>Are you sure?</span>
              <button className="btn-delete-confirm" onClick={() => onDelete(note.id)}>
                Yes, Delete
              </button>
              <button className="btn-cancel" onClick={() => setShowDelete(false)}>
                Cancel
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// useState needs to be imported — it's used in NoteCard above
import { useState } from "react";
