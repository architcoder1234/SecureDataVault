# =============================================================================
# FILE: app.py
# PURPOSE: Flask backend — API routes, JWT authentication, global error handler
# RUN: python app.py
# =============================================================================

import os
import logging
import logging.handlers
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import Flask, request, jsonify
from flask_cors import CORS
import jwt
from dotenv import load_dotenv

from crypto_utils import (
    encrypt_note, decrypt_note,
    generate_rsa_keys,
    rsa_encrypt, rsa_decrypt,
    sign_data, verify_signature
)
from auth_utils import hash_password, verify_password
from database import (
    init_db,
    create_user, get_user_by_username,
    save_note, get_notes_by_user, delete_note
)

# ─────────────────────────────────────────────────────────────────────────────
# SETUP: Load environment variables and configure secure logging
# ─────────────────────────────────────────────────────────────────────────────

load_dotenv()

# OWASP: Log errors to a FILE — never expose stack traces to the user.
# RotatingFileHandler prevents the log file from growing infinitely.
log_handler = logging.handlers.RotatingFileHandler(
    "vault_errors.log",
    maxBytes=5 * 1024 * 1024,  # 5 MB max per file
    backupCount=3               # Keep 3 old log files
)
log_handler.setLevel(logging.ERROR)
log_handler.setFormatter(logging.Formatter(
    "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
))

logging.basicConfig(level=logging.ERROR, handlers=[log_handler])
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# FLASK APP INITIALIZATION
# ─────────────────────────────────────────────────────────────────────────────

app = Flask(__name__)

# CORS: Only allow requests from your React dev server (localhost:3000)
# In production, replace with your actual domain.
CORS(app, resources={r"/api/*": {"origins": "http://localhost:3000"}})

# Load critical secrets from .env (NEVER hardcode these)
AES_KEY = os.getenv("AES_KEY", "").encode("utf-8")
JWT_SECRET = os.getenv("JWT_SECRET", "change-this-in-production")

if not AES_KEY:
    raise RuntimeError("AES_KEY not found in .env! Run generate_env_key.py first.")

# Generate RSA key pair at startup (in production, load from persistent files)
RSA_PRIVATE_KEY, RSA_PUBLIC_KEY = generate_rsa_keys()

# Initialize SQLite tables
init_db()


# ─────────────────────────────────────────────────────────────────────────────
# GLOBAL ERROR HANDLERS — OWASP: Never leak stack traces to users
# ─────────────────────────────────────────────────────────────────────────────

@app.errorhandler(Exception)
def handle_all_exceptions(e):
    """
    Catches ANY unhandled exception in the entire app.

    SECURITY RULE:
      - Log the FULL technical error (with traceback) to the log FILE.
      - Return ONLY a generic message to the user.
      - This prevents attackers from learning your server internals
        (database structure, library versions, file paths, etc.)
    """
    logger.error(f"Unhandled exception: {str(e)}", exc_info=True)
    return jsonify({"error": "Unable to process request. Please try again."}), 500


@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Resource not found."}), 404


@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"error": "Method not allowed."}), 405


# ─────────────────────────────────────────────────────────────────────────────
# JWT AUTHENTICATION DECORATOR
# WHY JWT? Stateless — no server-side sessions needed. Token has expiry built in.
# ─────────────────────────────────────────────────────────────────────────────

def token_required(f):
    """
    Decorator that protects routes by validating a JWT bearer token.

    Usage: Add @token_required above any route that needs login.
    The token is read from the "Authorization: Bearer <token>" header.

    After successful validation, sets:
      request.user_id  — the authenticated user's database ID
      request.username — the authenticated user's username
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return jsonify({"error": "Authentication required."}), 401

        token = auth_header.replace("Bearer ", "")
        try:
            payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
            request.user_id = payload["user_id"]
            request.username = payload["username"]
        except jwt.ExpiredSignatureError:
            return jsonify({"error": "Session expired. Please log in again."}), 401
        except jwt.InvalidTokenError:
            return jsonify({"error": "Invalid authentication token."}), 401

        return f(*args, **kwargs)
    return decorated


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: Health Check
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/api/status", methods=["GET"])
def status():
    """Public endpoint — shows vault is online and what security is active."""
    return jsonify({
        "status": "🔒 Vault is online",
        "symmetric_encryption": "AES-256 (Fernet)",
        "asymmetric_encryption": "RSA-2048 (OAEP)",
        "digital_signatures": "RSA-PSS with SHA-256",
        "password_hashing": "bcrypt (rounds=12)",
        "sql_protection": "Parameterized Queries",
        "tls": "Configure with self-signed cert (see SETUP_GUIDE.md)"
    }), 200


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: User Registration
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/api/register", methods=["POST"])
def register():
    """
    Registers a new user.

    SECURITY FLOW:
      1. Validate input (length, empty check).
      2. Check username isn't already taken.
      3. Hash the password with bcrypt.
      4. Store (username, bcrypt_hash) — NEVER the plain password.
    """
    try:
        body = request.get_json()
        if not body:
            return jsonify({"error": "Request body is required."}), 400

        username = str(body.get("username", "")).strip()
        password = str(body.get("password", ""))

        # --- Input Validation ---
        if not username or not password:
            return jsonify({"error": "Username and password are required."}), 400
        if len(username) < 3 or len(username) > 30:
            return jsonify({"error": "Username must be 3–30 characters."}), 400
        if len(password) < 8:
            return jsonify({"error": "Password must be at least 8 characters."}), 400
        if not username.isalnum():
            return jsonify({"error": "Username must contain only letters and numbers."}), 400

        # --- Check for duplicate ---
        if get_user_by_username(username):
            return jsonify({"error": "Username already taken."}), 409

        # --- Hash and store ---
        password_hash = hash_password(password)
        user_id = create_user(username, password_hash)

        return jsonify({
            "message": "Account created successfully. Please log in.",
            "user_id": user_id
        }), 201

    except ValueError as e:
        return jsonify({"error": str(e)}), 409
    except Exception as e:
        logger.error(f"Register error: {e}", exc_info=True)
        return jsonify({"error": "Unable to process request."}), 500


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: User Login
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/api/login", methods=["POST"])
def login():
    """
    Authenticates a user and returns a JWT token.

    SECURITY NOTE: We return the SAME error message whether the username
    doesn't exist OR the password is wrong. This prevents "username enumeration"
    — an attacker probing which usernames are valid.
    """
    try:
        body = request.get_json()
        if not body:
            return jsonify({"error": "Request body is required."}), 400

        username = str(body.get("username", "")).strip()
        password = str(body.get("password", ""))

        if not username or not password:
            return jsonify({"error": "Username and password are required."}), 400

        # Fetch user (parameterized query inside)
        user = get_user_by_username(username)

        # SECURITY: Same error for "user not found" and "wrong password"
        if not user or not verify_password(password, user["password_hash"]):
            return jsonify({"error": "Invalid username or password."}), 401

        # Generate JWT token (valid for 1 hour)
        token = jwt.encode(
            {
                "user_id": user["id"],
                "username": user["username"],
                "exp": datetime.now(timezone.utc) + timedelta(hours=1)
            },
            JWT_SECRET,
            algorithm="HS256"
        )

        return jsonify({
            "token": token,
            "username": user["username"],
            "message": "Login successful."
        }), 200

    except Exception as e:
        logger.error(f"Login error: {e}", exc_info=True)
        return jsonify({"error": "Unable to process request."}), 500


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: Add a Secure Note
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/api/notes", methods=["POST"])
@token_required
def add_note():
    """
    Encrypts and saves a user's note.

    SECURITY FLOW:
      1. Validate the note is not empty.
      2. AES-256 ENCRYPT the note text.
      3. RSA SIGN the encrypted ciphertext (not the plain text).
      4. Save ONLY (encrypted_text, signature) to DB — plain text never stored.
    """
    try:
        body = request.get_json()
        if not body:
            return jsonify({"error": "Request body is required."}), 400

        note_text = str(body.get("note", "")).strip()

        if not note_text:
            return jsonify({"error": "Note cannot be empty."}), 400
        if len(note_text) > 5000:
            return jsonify({"error": "Note cannot exceed 5000 characters."}), 400

        # Step 1: AES-256 encrypt the note
        encrypted = encrypt_note(note_text, AES_KEY)

        # Step 2: Sign the encrypted text with RSA private key
        signature = sign_data(encrypted, RSA_PRIVATE_KEY)

        # Step 3: Save to database (parameterized inside save_note)
        note_id = save_note(request.user_id, encrypted, signature)

        return jsonify({
            "message": "Note saved and encrypted successfully.",
            "note_id": note_id,
            "encrypted_preview": encrypted[:50] + "...",
            "signed": True
        }), 201

    except Exception as e:
        logger.error(f"Add note error: {e}", exc_info=True)
        return jsonify({"error": "Unable to process request."}), 500


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: Get All Notes (with Signature Verification + Decryption)
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/api/notes", methods=["GET"])
@token_required
def get_notes():
    """
    Retrieves and decrypts all notes for the logged-in user.

    SECURITY FLOW per note:
      1. VERIFY the RSA signature first — if invalid, data was tampered.
      2. Only if valid: AES-256 DECRYPT to get plain text.
      3. Report integrity status to the frontend.

    WHY VERIFY BEFORE DECRYPT?
      If an attacker modifies the database directly (encrypted_note column),
      decryption would fail or return garbage. Signature check catches this first.
    """
    try:
        raw_notes = get_notes_by_user(request.user_id)
        result = []

        for note in raw_notes:
            # --- Step 1: Verify digital signature ---
            is_valid = verify_signature(
                note["encrypted_note"],
                note["signature"],
                RSA_PUBLIC_KEY
            )

            if is_valid:
                try:
                    # --- Step 2: Decrypt only if signature is valid ---
                    plain_text = decrypt_note(note["encrypted_note"], AES_KEY)
                    result.append({
                        "id": note["id"],
                        "content": plain_text,
                        "created_at": note["created_at"],
                        "integrity": "verified",
                        "integrity_label": "✅ Signature Verified"
                    })
                except RuntimeError:
                    result.append({
                        "id": note["id"],
                        "content": "[Decryption failed — key may have changed]",
                        "created_at": note["created_at"],
                        "integrity": "decrypt_failed",
                        "integrity_label": "❌ Decryption Failed"
                    })
            else:
                # Signature invalid — data was tampered with
                result.append({
                    "id": note["id"],
                    "content": "[Note blocked — integrity check failed]",
                    "created_at": note["created_at"],
                    "integrity": "tampered",
                    "integrity_label": "⚠️ Signature Invalid — Tampered Data"
                })

        return jsonify({"notes": result, "count": len(result)}), 200

    except Exception as e:
        logger.error(f"Get notes error: {e}", exc_info=True)
        return jsonify({"error": "Unable to process request."}), 500


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: Delete a Note
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/api/notes/<int:note_id>", methods=["DELETE"])
@token_required
def remove_note(note_id):
    """
    Deletes a note — only if it belongs to the logged-in user.
    database.delete_note() uses TWO conditions: note_id AND user_id.
    This prevents IDOR (Insecure Direct Object Reference) attacks.
    """
    try:
        deleted = delete_note(note_id, request.user_id)
        if deleted:
            return jsonify({"message": "Note deleted."}), 200
        else:
            return jsonify({"error": "Note not found or access denied."}), 404
    except Exception as e:
        logger.error(f"Delete note error: {e}", exc_info=True)
        return jsonify({"error": "Unable to process request."}), 500


# ─────────────────────────────────────────────────────────────────────────────
# ROUTE: RSA Demo — Encrypt a small message with the public key
# ─────────────────────────────────────────────────────────────────────────────

@app.route("/api/demo/rsa-encrypt", methods=["POST"])
@token_required
def demo_rsa_encrypt():
    """
    Demo: Shows RSA public key encryption in action.
    Useful for demonstrating how the AES key itself would be shared securely.
    """
    try:
        body = request.get_json()
        message = str(body.get("message", "")).strip()

        if not message or len(message) > 200:
            return jsonify({"error": "Message must be 1–200 characters."}), 400

        encrypted_b64 = rsa_encrypt(message.encode("utf-8"), RSA_PUBLIC_KEY)

        return jsonify({
            "original": message,
            "encrypted_rsa": encrypted_b64,
            "note": "Encrypted with RSA-2048 public key. Only the server private key can decrypt."
        }), 200

    except Exception as e:
        logger.error(f"RSA demo error: {e}", exc_info=True)
        return jsonify({"error": "Unable to process request."}), 500


# ─────────────────────────────────────────────────────────────────────────────
# MAIN ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("🔒 Secure Data Vault Backend Starting...")
    print("   AES-256  : Ready")
    print("   RSA-2048 : Ready")
    print("   bcrypt   : Ready")
    print("   SQLite   : Ready")
    print("   Running on http://localhost:5000")
    print("   (For HTTPS, see SETUP_GUIDE.md — SSL/TLS section)")

    # IMPORTANT: debug=False prevents Flask from showing stack traces in browser
    # host="0.0.0.0" allows connections from React dev server on same machine
    app.run(debug=False, host="0.0.0.0", port=5000)
