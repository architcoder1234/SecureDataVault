// =============================================================================
// FILE: src/App.jsx
// PURPOSE: Root component — manages auth state and which page to show
// =============================================================================

import { useState, useEffect } from "react";
import AuthForm from "./components/AuthForm";
import VaultDashboard from "./components/VaultDashboard";
import TrustStatus from "./components/TrustStatus";
import "./App.css";

export default function App() {
  // auth holds { token, username } after login, or null if logged out
  const [auth, setAuth] = useState(null);
  const [appReady, setAppReady] = useState(false);

  // On first load, check if a JWT token is saved in sessionStorage.
  // WHY sessionStorage and not localStorage?
  //   sessionStorage is cleared when the browser tab is closed.
  //   localStorage persists forever — a bigger risk if the device is shared.
  useEffect(() => {
    const savedToken = sessionStorage.getItem("vault_token");
    const savedUsername = sessionStorage.getItem("vault_username");
    if (savedToken && savedUsername) {
      setAuth({ token: savedToken, username: savedUsername });
    }
    setAppReady(true);
  }, []);

  // Called by AuthForm after a successful login
  const handleLogin = (token, username) => {
    sessionStorage.setItem("vault_token", token);
    sessionStorage.setItem("vault_username", username);
    setAuth({ token, username });
  };

  // Called when user clicks "Logout"
  const handleLogout = () => {
    sessionStorage.removeItem("vault_token");
    sessionStorage.removeItem("vault_username");
    setAuth(null);
  };

  if (!appReady) return null; // Prevent flash before auth check

  return (
    <div className="app-root">
      {/* Header */}
      <header className="app-header">
        <div className="header-left">
          <span className="header-lock">🔒</span>
          <h1 className="header-title">Secure Data Vault</h1>
        </div>
        {auth && (
          <div className="header-right">
            <span className="header-user">👤 {auth.username}</span>
            <button className="btn-logout" onClick={handleLogout}>
              Logout
            </button>
          </div>
        )}
      </header>

      {/* Trust/SSL Status Banner */}
      <TrustStatus />

      {/* Main Content */}
      <main className="app-main">
        {auth ? (
          <VaultDashboard token={auth.token} username={auth.username} />
        ) : (
          <AuthForm onLoginSuccess={handleLogin} />
        )}
      </main>

      {/* Footer */}
      <footer className="app-footer">
        <p>
          🛡️ AES-256 Encryption &nbsp;|&nbsp; RSA-2048 Signatures &nbsp;|&nbsp;
          bcrypt Hashing &nbsp;|&nbsp; OWASP Secure Coding
        </p>
      </footer>
    </div>
  );
}
