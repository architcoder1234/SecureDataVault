# =============================================================================
# FILE: database.py
# PURPOSE: SQLite database setup with PARAMETERIZED QUERIES (OWASP Anti-SQLi)
# =============================================================================

# WHAT IS SQL INJECTION?
# ----------------------
# If you build queries like this (WRONG):
#   query = "SELECT * FROM users WHERE username = '" + username + "'"
#   If username = "admin' OR '1'='1" — the attacker bypasses all auth!
#
# PARAMETERIZED QUERIES (RIGHT):
#   cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
#   The ? is a PLACEHOLDER. SQLite treats the input as pure DATA, not SQL code.
#   Even if the user types SQL commands, they are escaped automatically.

import sqlite3
import logging
import os

logger = logging.getLogger(__name__)

DB_PATH = os.path.join(os.path.dirname(__file__), "vault.db")


def get_connection() -> sqlite3.Connection:
    """
    Opens a database connection.
    row_factory = sqlite3.Row lets us access columns by name (like a dict).
    """
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    # Enable foreign key enforcement (SQLite disables it by default)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """
    Creates the database tables if they don't already exist.
    Called once when the Flask app starts.

    TABLE DESIGN:
      users  — stores username + bcrypt password hash (NEVER plain password)
      notes  — stores AES-encrypted note + RSA digital signature
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()

        # ---- USERS TABLE ----
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                username      TEXT    UNIQUE NOT NULL,
                password_hash TEXT    NOT NULL,
                created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # ---- NOTES TABLE ----
        # encrypted_note : AES-256 ciphertext (safe to store, unreadable without key)
        # signature      : RSA digital signature to detect tampering
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS notes (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id        INTEGER NOT NULL,
                encrypted_note TEXT    NOT NULL,
                signature      TEXT    NOT NULL,
                created_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)

        conn.commit()
        logger.info("Database initialized successfully.")
    except Exception as e:
        logger.error(f"Database init failed: {e}")
        raise
    finally:
        conn.close()  # Always close — prevents connection leaks


# =============================================================================
# USER OPERATIONS — All using PARAMETERIZED QUERIES
# =============================================================================

def create_user(username: str, password_hash: str) -> int:
    """
    Inserts a new user into the database.

    SECURITY: password_hash is already a bcrypt hash from auth_utils.py.
    We NEVER receive or store the plain password here.

    Returns: The new user's ID.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        # ? placeholders prevent SQL injection
        cursor.execute(
            "INSERT INTO users (username, password_hash) VALUES (?, ?)",
            (username, password_hash)   # Tuple of values — mapped to ? in order
        )
        conn.commit()
        return cursor.lastrowid
    except sqlite3.IntegrityError:
        raise ValueError("Username already exists.")
    except Exception as e:
        logger.error(f"create_user failed: {e}")
        raise RuntimeError("Unable to process request.")
    finally:
        conn.close()


def get_user_by_username(username: str) -> dict | None:
    """
    Fetches a user record by username.

    ANTI SQL-INJECTION EXAMPLE:
      BAD:  f"SELECT * FROM users WHERE username = '{username}'"
      GOOD: "SELECT * FROM users WHERE username = ?", (username,)

    Returns: A dict with user data, or None if not found.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM users WHERE username = ?",
            (username,)
        )
        row = cursor.fetchone()
        return dict(row) if row else None
    except Exception as e:
        logger.error(f"get_user_by_username failed: {e}")
        return None
    finally:
        conn.close()


def get_user_by_id(user_id: int) -> dict | None:
    """Fetches a user record by their ID."""
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        row = cursor.fetchone()
        return dict(row) if row else None
    except Exception as e:
        logger.error(f"get_user_by_id failed: {e}")
        return None
    finally:
        conn.close()


# =============================================================================
# NOTES OPERATIONS
# =============================================================================

def save_note(user_id: int, encrypted_note: str, signature: str) -> int:
    """
    Saves an AES-encrypted note + its RSA signature to the database.

    NOTE: We save the ENCRYPTED text and the SIGNATURE.
          The plain text NEVER touches the database.

    Returns: The new note's ID.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO notes (user_id, encrypted_note, signature) VALUES (?, ?, ?)",
            (user_id, encrypted_note, signature)
        )
        conn.commit()
        return cursor.lastrowid
    except Exception as e:
        logger.error(f"save_note failed: {e}")
        raise RuntimeError("Unable to process request.")
    finally:
        conn.close()


def get_notes_by_user(user_id: int) -> list[dict]:
    """
    Retrieves all notes belonging to a specific user.

    IMPORTANT: user_id comes from the JWT token (verified server-side),
               NOT from user input. This prevents horizontal privilege
               escalation (a user accessing another user's notes).

    Returns: List of note dicts ordered newest first.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM notes WHERE user_id = ? ORDER BY created_at DESC",
            (user_id,)
        )
        return [dict(row) for row in cursor.fetchall()]
    except Exception as e:
        logger.error(f"get_notes_by_user failed: {e}")
        return []
    finally:
        conn.close()


def delete_note(note_id: int, user_id: int) -> bool:
    """
    Deletes a note — but ONLY if it belongs to the requesting user.

    WHY TWO CONDITIONS?
      Without the user_id check, user A could delete user B's notes
      by guessing note IDs. This is called an IDOR vulnerability (OWASP A01).

    Returns: True if a row was deleted, False otherwise.
    """
    conn = get_connection()
    try:
        cursor = conn.cursor()
        cursor.execute(
            "DELETE FROM notes WHERE id = ? AND user_id = ?",
            (note_id, user_id)
        )
        conn.commit()
        return cursor.rowcount > 0
    except Exception as e:
        logger.error(f"delete_note failed: {e}")
        return False
    finally:
        conn.close()
