// =============================================================================
// FILE: src/components/VaultDashboard.jsx
// PURPOSE: Main dashboard after login — add notes and view decrypted vault
// =============================================================================

import { useState, useEffect, useCallback } from "react";
import NotesList from "./NotesList";

const API = "http://localhost:5000/api";

export default function VaultDashboard({ token, username }) {
  const [noteText, setNoteText] = useState("");
  const [notes, setNotes] = useState([]);
  const [addLoading, setAddLoading] = useState(false);
  const [fetchLoading, setFetchLoading] = useState(true);
  const [addError, setAddError] = useState("");
  const [addSuccess, setAddSuccess] = useState("");
  const [rsaMessage, setRsaMessage] = useState("");
  const [rsaResult, setRsaResult] = useState(null);
  const [rsaLoading, setRsaLoading] = useState(false);

  // Auth header used for every protected API call
  const authHeaders = {
    "Content-Type": "application/json",
    "Authorization": `Bearer ${token}`
  };

  // ─── Fetch all notes ───────────────────────────────────────────────────────
  const fetchNotes = useCallback(async () => {
    setFetchLoading(true);
    try {
      const res = await fetch(`${API}/notes`, { headers: authHeaders });
      const data = await res.json();
      if (res.ok) {
        setNotes(data.notes || []);
      } else {
        console.error("Failed to fetch notes:", data.error);
      }
    } catch {
      console.error("Network error fetching notes.");
    } finally {
      setFetchLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchNotes();
  }, [fetchNotes]);

  // ─── Add a new encrypted note ──────────────────────────────────────────────
  const handleAddNote = async (e) => {
    e.preventDefault();
    setAddError("");
    setAddSuccess("");

    const trimmed = noteText.trim();
    if (!trimmed) {
      setAddError("Note cannot be empty.");
      return;
    }
    if (trimmed.length > 5000) {
      setAddError("Note cannot exceed 5000 characters.");
      return;
    }

    setAddLoading(true);
    try {
      const res = await fetch(`${API}/notes`, {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({ note: trimmed })
      });
      const data = await res.json();

      if (res.ok) {
        setAddSuccess(`Note encrypted and saved. (Preview: ${data.encrypted_preview})`);
        setNoteText("");
        fetchNotes(); // Refresh the list
      } else {
        setAddError(data.error || "Failed to save note.");
      }
    } catch {
      setAddError("Cannot connect to vault server.");
    } finally {
      setAddLoading(false);
    }
  };

  // ─── Delete a note ─────────────────────────────────────────────────────────
  const handleDeleteNote = async (noteId) => {
    try {
      const res = await fetch(`${API}/notes/${noteId}`, {
        method: "DELETE",
        headers: authHeaders
      });
      if (res.ok) {
        setNotes((prev) => prev.filter((n) => n.id !== noteId));
      }
    } catch {
      console.error("Delete failed.");
    }
  };

  // ─── RSA Demo ──────────────────────────────────────────────────────────────
  const handleRsaDemo = async (e) => {
    e.preventDefault();
    setRsaResult(null);
    if (!rsaMessage.trim()) return;

    setRsaLoading(true);
    try {
      const res = await fetch(`${API}/demo/rsa-encrypt`, {
        method: "POST",
        headers: authHeaders,
        body: JSON.stringify({ message: rsaMessage.trim() })
      });
      const data = await res.json();
      if (res.ok) setRsaResult(data);
    } catch {
      console.error("RSA demo failed.");
    } finally {
      setRsaLoading(false);
    }
  };

  return (
    <div className="dashboard">
      {/* ── Add Note Section ── */}
      <section className="vault-section">
        <h2 className="section-title">📝 Add a Secret Note</h2>
        <p className="section-desc">
          Your note will be <strong>AES-256 encrypted</strong> and <strong>RSA signed</strong> before being stored.
          The plain text NEVER touches the database.
        </p>

        <form onSubmit={handleAddNote} className="note-form" noValidate>
          <textarea
            className="note-textarea"
            value={noteText}
            onChange={(e) => setNoteText(e.target.value)}
            placeholder="Type your secret note here..."
            rows={5}
            maxLength={5000}
            disabled={addLoading}
          />
          <div className="char-count">{noteText.length} / 5000</div>

          {addError && <div className="msg-error">⚠️ {addError}</div>}
          {addSuccess && <div className="msg-success">✅ {addSuccess}</div>}

          <button type="submit" className="btn-primary" disabled={addLoading}>
            {addLoading ? "⏳ Encrypting..." : "🔒 Encrypt & Save Note"}
          </button>
        </form>
      </section>

      {/* ── Notes List Section ── */}
      <section className="vault-section">
        <h2 className="section-title">🗄️ Your Vault ({notes.length} notes)</h2>
        <p className="section-desc">
          Each note is verified with its <strong>RSA digital signature</strong> before decryption.
          If a note was tampered with, it will be flagged.
        </p>

        <NotesList
          notes={notes}
          loading={fetchLoading}
          onDelete={handleDeleteNote}
          onRefresh={fetchNotes}
        />
      </section>

      {/* ── RSA Demo Section ── */}
      <section className="vault-section demo-section">
        <h2 className="section-title">🔬 RSA Encryption Demo</h2>
        <p className="section-desc">
          See RSA public-key encryption live. Type a short message — the server will
          encrypt it with the <strong>RSA-2048 public key</strong>. Only the server's
          private key can decrypt it.
        </p>

        <form onSubmit={handleRsaDemo} className="demo-form" noValidate>
          <input
            type="text"
            className="demo-input"
            value={rsaMessage}
            onChange={(e) => setRsaMessage(e.target.value)}
            placeholder="e.g. my-secret-aes-key"
            maxLength={200}
            disabled={rsaLoading}
          />
          <button type="submit" className="btn-secondary" disabled={rsaLoading || !rsaMessage.trim()}>
            {rsaLoading ? "⏳ Encrypting..." : "🔐 RSA Encrypt"}
          </button>
        </form>

        {rsaResult && (
          <div className="rsa-result">
            <p><strong>Original:</strong> {rsaResult.original}</p>
            <p><strong>RSA Ciphertext (Base64):</strong></p>
            <code className="cipher-text">{rsaResult.encrypted_rsa}</code>
            <p className="rsa-note">💡 {rsaResult.note}</p>
          </div>
        )}
      </section>
    </div>
  );
}
