// =============================================================================
// FILE: src/components/AuthForm.jsx
// PURPOSE: Login / Register form with client-side validation
// =============================================================================

import { useState } from "react";

const API = "http://localhost:5000/api";

export default function AuthForm({ onLoginSuccess }) {
  const [mode, setMode] = useState("login"); // "login" | "register"
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  // ─── Client-side validation (first line of defense) ───────────────────────
  // NOTE: Server ALSO validates — never trust only the frontend.
  const validate = () => {
    if (!username.trim() || !password.trim()) {
      return "Username and password are required.";
    }
    if (username.length < 3) {
      return "Username must be at least 3 characters.";
    }
    if (!/^[a-zA-Z0-9]+$/.test(username)) {
      return "Username must contain only letters and numbers.";
    }
    if (password.length < 8) {
      return "Password must be at least 8 characters.";
    }
    if (mode === "register" && password !== confirmPassword) {
      return "Passwords do not match.";
    }
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); // Prevent default form submission
    setError("");
    setSuccess("");

    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    setLoading(true);
    try {
      const endpoint = mode === "login" ? "/login" : "/register";
      const response = await fetch(`${API}${endpoint}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: username.trim(), password })
      });

      const data = await response.json();

      if (!response.ok) {
        // Show the server's error message (generic, safe messages from backend)
        setError(data.error || "Something went wrong. Please try again.");
        return;
      }

      if (mode === "register") {
        setSuccess("Account created! You can now log in.");
        setMode("login");
        setPassword("");
        setConfirmPassword("");
      } else {
        // Login success — pass token up to App.jsx
        onLoginSuccess(data.token, data.username);
      }
    } catch (err) {
      // Network error (server down, CORS issue, etc.)
      setError("Cannot connect to the vault server. Is the backend running?");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <div className="auth-card">
        <div className="auth-icon">🔐</div>
        <h2>{mode === "login" ? "Unlock Your Vault" : "Create a Vault"}</h2>

        {/* Mode toggle */}
        <div className="auth-tabs">
          <button
            className={`auth-tab ${mode === "login" ? "active" : ""}`}
            onClick={() => { setMode("login"); setError(""); setSuccess(""); }}
          >
            Login
          </button>
          <button
            className={`auth-tab ${mode === "register" ? "active" : ""}`}
            onClick={() => { setMode("register"); setError(""); setSuccess(""); }}
          >
            Register
          </button>
        </div>

        <form onSubmit={handleSubmit} className="auth-form" noValidate>
          {/* Username */}
          <div className="field-group">
            <label htmlFor="username">Username</label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Letters and numbers only"
              autoComplete="username"
              maxLength={30}
              disabled={loading}
            />
          </div>

          {/* Password */}
          <div className="field-group">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimum 8 characters"
              autoComplete={mode === "login" ? "current-password" : "new-password"}
              disabled={loading}
            />
          </div>

          {/* Confirm Password (register only) */}
          {mode === "register" && (
            <div className="field-group">
              <label htmlFor="confirm">Confirm Password</label>
              <input
                id="confirm"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Repeat your password"
                autoComplete="new-password"
                disabled={loading}
              />
            </div>
          )}

          {/* Error / Success messages */}
          {error && <div className="msg-error">⚠️ {error}</div>}
          {success && <div className="msg-success">✅ {success}</div>}

          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? "⏳ Please wait..." : mode === "login" ? "🔓 Login" : "🔒 Create Account"}
          </button>
        </form>

        {/* Security info panel */}
        <div className="auth-security-info">
          <p>🛡️ <strong>How your password is protected:</strong></p>
          <p>Your password is hashed with <strong>bcrypt (rounds=12)</strong> before storage. 
             The database NEVER contains your plain password — not even the server admin can read it.</p>
        </div>
      </div>
    </div>
  );
}
